/**
 * Refactor `data` to a new file.
 * Ctrl + . will reveal the refactoring options.
 */

export const data = {
  app: {
    generalInformation: {
      title: 'Alex Sitja'
    },
    footer: {
      author: 'Alex Sitja Jurado',
      email: 'asitja@inscastellet.cat'
    }
  }
};
