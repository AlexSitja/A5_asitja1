export class bird{
    Birdname: string;
    Wingspan: string;
    eggsize: number;
    constructor (){
        this.Birdname = "";
        this.Wingspan = "";
        this.eggsize = 0;
    }

}